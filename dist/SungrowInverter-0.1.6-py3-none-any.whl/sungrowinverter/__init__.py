"""
SungrowInverter client query modbus registers via TCP only
"""
from sungrowinverter.SungrowInverter import SungrowInverter